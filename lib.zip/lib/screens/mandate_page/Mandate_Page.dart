import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:moneyphi/utils/Colors.dart';
import 'package:moneyphi/utils/SizeConfig.dart';
import 'package:moneyphi/widgets/moneyPhiButton.dart';
import 'package:provider/provider.dart';

import '../../controller/check_out_controller.dart';
import 'account_details.dart';
import 'offline_autopay.dart';

class MandatePage extends StatefulWidget {
  @override
  State<MandatePage> createState() => _MandatePageState();
}

class _MandatePageState extends State<MandatePage> {
  @override
  void initState() {
    Provider.of<GetBankDetailsController>(context, listen: false)
        .getBankDetails(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: BackButton(
          color: Theme.of(context).textTheme.headline3?.color,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.all(15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 10,
                ),
                Text(
                  "Set Up Your Autopay",
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w700,
                      fontSize: 20),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  "Clickpay (mandate) will automate your investments from your registered bank account.",
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
                SizedBox(
                  height: 30,
                ),
                Text(
                  "Your Bank Details",
                  style: TextStyle(color: Colors.black, fontSize: 16),
                ),
                SizedBox(
                  height: 10,
                ),
                Consumer<GetBankDetailsController>(
                    builder: (context, controller, child) {
                  return controller.isLoading == true
                      ? Center(child: CircularProgressIndicator())
                      : ListView.builder(
                          itemCount:
                              controller.getBankDetailsModel!.banksData!.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            return AccountDetails(
                                bankData: controller
                                    .getBankDetailsModel!.banksData!
                                    .elementAt(index));
                          },
                        );
                }),
                SizedBox(
                  height: 10,
                ),
                Container(
                  width: SizeConfig.screenWidth,
                  child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    child: Container(
                      padding: EdgeInsets.all(10),
                      child: Column(
                        children: [
                          SizedBox(
                            height: 10,
                          ),

                          // Image.network("https://1000logos.net/wp-content/uploads/2021/06/HDFC-Bank-emblem.png",height:70,width: 70,),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text("Minimum Auto Debit Limit"),
                              SizedBox(
                                width: 10,
                              ),
                              CircleAvatar(
                                  radius: 15,
                                  backgroundColor: Colors.blue,
                                  child: Icon(
                                    Icons.question_mark,
                                    color: Colors.white,
                                    size: 18,
                                  ))
                            ],
                          ),
                          SizedBox(
                            height: 7,
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 15, vertical: 10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: appColorPrimary),
                            child: Text(
                              "₹ 50000",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            height: 40,
                            child: ListView(
                              scrollDirection: Axis.horizontal,
                              children: [
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 15, vertical: 10),
                                  margin: EdgeInsets.symmetric(horizontal: 5),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      border:
                                          Border.all(color: appColorPrimary)),
                                  child: Text(
                                    "₹ 10000",
                                    style: TextStyle(color: Colors.black),
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 15, vertical: 10),
                                  margin: EdgeInsets.symmetric(horizontal: 5),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      border:
                                          Border.all(color: appColorPrimary)),
                                  child: Text(
                                    "₹ 25000",
                                    style: TextStyle(color: Colors.black),
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 15, vertical: 10),
                                  margin: EdgeInsets.symmetric(horizontal: 5),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      border:
                                          Border.all(color: appColorPrimary)),
                                  child: Text(
                                    "₹ 50000",
                                    style: TextStyle(color: Colors.black),
                                  ),
                                ),
                                Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 15, vertical: 10),
                                  margin: EdgeInsets.symmetric(horizontal: 5),
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      border:
                                          Border.all(color: appColorPrimary)),
                                  child: Text(
                                    "₹ 100000",
                                    style: TextStyle(color: Colors.black),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 20,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                Text("Dont have access to online banking?"),
                SizedBox(
                  height: 15,
                ),
                RichText(
                  text: new TextSpan(
                    text: 'To Create offline Autopay ',
                    style: TextStyle(
                        fontSize: 13,
                        color: Theme.of(context).textTheme.headline3!.color),
                    children: <TextSpan>[
                      new TextSpan(
                          text: 'Click Here',
                          style: new TextStyle(color: Colors.blue)),
                    ],
                  ),
                ),
                SizedBox(
                  height: 3,
                ),
                Text(
                  "(This will take upto 30 days to approve and start your SIP)",
                  style: TextStyle(color: Colors.blue),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: MoneyPhiButton(
        buttonTitle: "Create AutoPay",
        onClick: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => OfflineAutopay()));
        },
      ),
    );
  }
}
