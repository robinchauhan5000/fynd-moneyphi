part of 'bsc_code_bloc.dart';

abstract class BscCodeEvent {
  const BscCodeEvent();
}

class BscCodeFetch extends BscCodeEvent {}
