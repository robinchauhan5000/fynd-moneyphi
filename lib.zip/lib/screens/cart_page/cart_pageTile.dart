import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:moneyphi/controller/MutualFundsController.dart';
import 'package:moneyphi/theme/theme.dart';
import 'package:moneyphi/utils/SizeConfig.dart';
import 'package:provider/provider.dart';

import '../cart/cart_date_alertbox.dart';

class CartPageTile extends StatelessWidget {
  String? fundshipName;
  String? minSip;
  String? duration;
  String? sipAmount;
  int? itemIndex;
  int? userInputId;
  List<int>? sipDates;
  String? investmentType;
  int? fundshipId;
  CartPageTile(
      {this.itemIndex,
      this.duration,
      this.fundshipName,
      this.minSip,
      this.sipDates,
      this.userInputId,
      this.sipAmount,
      this.investmentType,
      this.fundshipId});

  @override
  Widget build(BuildContext context) {
    MutualFundsController mutualFundsController =
        Provider.of<MutualFundsController>(context, listen: false);
    return Consumer<MutualFundsController>(
        builder: (context, controller, child) {
      return Container(
        margin: EdgeInsets.all(10),
        padding: EdgeInsets.symmetric(vertical: 30),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.white,
          boxShadow: [mainboxshadow],
        ),
        child: Container(
          height: 100,
          padding: EdgeInsets.symmetric(
            horizontal: 10,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  SizedBox(
                    width: SizeConfig.screenWidth / fundshipName!.length * 30,
                    child: Text(
                      fundshipName!,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          height: 1.5),
                    ),
                  ),
                  Spacer(),
                  Icon(Icons.more_vert)
                ],
              ),
              Container(
                height: 50,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "SIP Amount",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 12,
                              fontWeight: FontWeight.w600),
                        ),
                        Text(
                          "Select SIP Date    ",
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 12,
                              fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "₹ " + sipAmount!,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 12,
                              fontWeight: FontWeight.w600),
                        ),
                        investmentType == "SIP"
                            ? GestureDetector(
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return CartDateAlert(
                                          sipDates: sipDates,
                                          fundshipId: fundshipId!);
                                    },
                                  );
                                },
                                child: Icon(
                                  Icons.calendar_month,
                                  color: Colors.blue,
                                ),
                              )
                            : Container(),
                      ],
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        InkWell(
                          onTap: () {
                            controller.removeAddedToCart(
                                context: context,
                                usergoalinputId: userInputId,
                                index: itemIndex);
                          },
                          child: Icon(Icons.delete_outline_outlined),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    });
  }
}
