import 'package:flutter/material.dart';
import 'package:moneyphi/controller/MutualFundsController.dart';
import 'package:provider/provider.dart';

import '../../Model/GetCartListModel.dart';
import '../mandate_page/Mandate_Page.dart';
import 'cart_pageTile.dart';

class CartPageList extends StatefulWidget {
  const CartPageList({Key? key}) : super(key: key);
  @override
  State<CartPageList> createState() => _CartPageListState();
}

class _CartPageListState extends State<CartPageList> {
  MutualFundsController? mutualFundsController;
  Fund? fundModel;

  @override
  void initState() {
    mutualFundsController =
        Provider.of<MutualFundsController>(context, listen: false);
    mutualFundsController!.getCartList(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: BackButton(
          color: Theme.of(context).textTheme.headline3?.color,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Consumer<MutualFundsController>(
            builder: (context, controller, child) {
          return controller.isLoading
              ? Column(
                  children: [
                    Center(child: CircularProgressIndicator()),
                  ],
                )
              : controller.getCartListModel == null
                  ? Center(
                      child: Column(
                        children: [
                          Icon(
                            Icons.remove_shopping_cart,
                            size: 50,
                          ),
                          Text("There is no item in the cart"),
                        ],
                      ),
                    )
                  : controller.getCartListModel?.cart == null
                      ? Center(
                          child: Column(
                            children: [
                              Icon(
                                Icons.remove_shopping_cart,
                                size: 50,
                              ),
                              Text("There is no item in the cart"),
                            ],
                          ),
                        )
                      : Column(
                          children: [
                            for (int i = 0;
                                i <
                                    controller
                                        .getCartListModel!.cart!.goals.length;
                                i++)
                              ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: controller.getCartListModel?.cart!
                                      .goals[i].funds.length,
                                  itemBuilder: (context, index) {
                                    return GestureDetector(
                                      onTap: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    MandatePage()));
                                      },
                                      child: CartPageTile(
                                          fundshipId: controller
                                              .getCartListModel
                                              ?.cart!
                                              .goals[i]
                                              .funds[index]
                                              .fundId,
                                          fundshipName: controller
                                              .getCartListModel
                                              ?.cart!
                                              .goals[i]
                                              .funds[index]
                                              .fundName,
                                          sipAmount: controller
                                              .getCartListModel
                                              ?.cart!
                                              .goals[i]
                                              .funds[index]
                                              .amount
                                              .toString(),
                                          userInputId: controller
                                              .getCartListModel!
                                              .cart!
                                              .goals[i]
                                              .inputId,
                                          sipDates: controller.getCartListModel!
                                              .cart!.goals[i].funds
                                              .elementAt(index)
                                              .sipDates,
                                          itemIndex: i,
                                          investmentType: controller
                                              .getCartListModel!
                                              .cart!
                                              .goals[i]
                                              .funds
                                              .elementAt(index)
                                              .investmentType),
                                    );
                                  })
                          ],
                        );
        }),
      ),
    );
  }
}
