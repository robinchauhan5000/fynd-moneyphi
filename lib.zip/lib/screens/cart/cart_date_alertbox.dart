import 'package:flutter/material.dart';
import 'package:moneyphi/controller/dashBoardController.dart';
import 'package:moneyphi/utils/Colors.dart';
import 'package:moneyphi/utils/SharedPref.dart';
import 'package:moneyphi/utils/SizeConfig.dart';
import 'package:provider/provider.dart';

class CartDateAlert extends StatefulWidget {
  List<int>? sipDates;
  int? fundshipId;

  CartDateAlert({this.sipDates, this.fundshipId});

  @override
  State<CartDateAlert> createState() => _CartDateAlertState();
}

class _CartDateAlertState extends State<CartDateAlert> {
  int? selectIndex;
  onDateSelect(index) {
    setState(() {
      selectIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: AlertDialog(
        insetPadding: EdgeInsets.zero,
        title: Column(
          children: [
            Text(
              "Pick a date for SIP",
              textAlign: TextAlign.center,
              style:
                  TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
            ),
            Divider(
              thickness: 1.5,
              height: 10,
            )
          ],
        ),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text("Cancel")),
              SizedBox(
                width: 20,
              ),
              Consumer<DashBoardController>(
                  builder: (context, controller, child) {
                return ElevatedButton(
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(
                          Theme.of(context).primaryColor),
                    ),
                    onPressed: () {
                      print("id${widget.fundshipId}");
                      SharedPref().setString(
                          key: "id${widget.fundshipId}",
                          value: (selectIndex! + 1).toString());

                      Navigator.pop(context);
                    },
                    child: Text("Save", style: TextStyle(color: Colors.white)));
              }),
            ],
          )
        ],
        content: Container(
          height: SizeConfig.screenHeight / 31 * 16,
          width: 200,
          child: GridView.count(
            crossAxisCount: 5,
            crossAxisSpacing: 2.0,
            mainAxisSpacing: 2.0,
            childAspectRatio: 1.0,
            shrinkWrap: true,
            children: List.generate(
              31,
              (index) => GestureDetector(
                onTap: () {
                  onDateSelect(index);
                },
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color:
                        index == selectIndex ? appColorPrimary : Colors.white,
                  ),
                  child: Text(
                    "${index + 1}",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: index == selectIndex
                            ? Colors.white
                            : widget.sipDates!.contains(index + 1)
                                ? Colors.black
                                : Colors.grey),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
