import 'dart:core';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../controller/MutualFundsController.dart';

class CategoryWidget extends StatefulWidget {
  dynamic index;
  String? name;
  String? subcat;
  double? verticleMargin;
  CategoryWidget({this.index, this.name, this.verticleMargin, this.subcat});
  @override
  State<CategoryWidget> createState() => _CategoryWidgetState();
}

class _CategoryWidgetState extends State<CategoryWidget> {
  MutualFundsController? mutualFundsController;
  @override
  void initState() {
    mutualFundsController =
        Provider.of<MutualFundsController>(context, listen: false);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<MutualFundsController>(
        builder: (context, controller, child) {
      return GestureDetector(
        onTap: () {
          onpress(widget.index);
          setState(() {
            widget.subcat = "";
          });
        },
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 20),
          margin: EdgeInsets.symmetric(
              horizontal: 5, vertical: widget.verticleMargin ?? 5),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: controller.subcats == widget.name
                  ? Colors.green
                  : Colors.white,
              border: Border.all(color: Colors.green)),
          child: Center(
            child: Text(
              widget.name!,
              style: TextStyle(
                  color: controller.subcats == widget.name
                      ? Colors.white
                      : Colors.black),
            ),
          ),
        ),
      );
    });
  }

  void onpress(index) {
    setState(() {
      mutualFundsController!
          .getsearchfunds(context, mutualFundsController!.cats, widget.name);
      widget.subcat = widget.name;
      print(widget.index);
    });
  }
}

class SubCategoryWidget extends StatefulWidget {
  dynamic index;
  String? name;
  String? subcat;
  double? verticleMargin;
  SubCategoryWidget({this.index, this.name, this.verticleMargin, this.subcat});
  @override
  State<SubCategoryWidget> createState() => _SubCategoryWidgetState();
}

class _SubCategoryWidgetState extends State<SubCategoryWidget> {
  MutualFundsController? mutualFundsController;
  @override
  void initState() {
    mutualFundsController =
        Provider.of<MutualFundsController>(context, listen: false);

    super.initState();
  }

  int? _selectIndex;
  @override
  Widget build(BuildContext context) {
    return Consumer<MutualFundsController>(
        builder: (context, controller, child) {
      return GestureDetector(
        onTap: () {
          onpress(widget.index);
          setState(() {
            widget.name = "";
          });
        },
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 20),
          margin: EdgeInsets.symmetric(
              horizontal: 5, vertical: widget.verticleMargin ?? 5),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color:
                  controller.cats == widget.name ? Colors.green : Colors.white,
              border: Border.all(color: Colors.green)),
          child: Center(
            child: Text(
              widget.name!,
              style: TextStyle(
                  color: controller.cats == widget.name
                      ? Colors.white
                      : Colors.black),
            ),
          ),
        ),
      );
    });
  }

  void onpress(index) {
    setState(() {
      mutualFundsController!
          .getsearchfunds(context, widget.name, mutualFundsController!.subcats);

      // widget.subcat = widget.name;
      print(widget.index);
    });
  }
}
