// To parse this JSON data, do
//
//     final getBankDetailsModel = getBankDetailsModelFromJson(jsonString);

import 'dart:convert';

GetBankDetailsModel getBankDetailsModelFromJson(String str) =>
    GetBankDetailsModel.fromJson(json.decode(str));

String getBankDetailsModelToJson(GetBankDetailsModel data) =>
    json.encode(data.toJson());

class GetBankDetailsModel {
  GetBankDetailsModel({
    this.success,
    this.totalBanks,
    this.banksData,
    this.mandatesData,
  });

  bool? success;
  int? totalBanks;
  List<BanksDatum>? banksData;
  List<dynamic>? mandatesData;

  factory GetBankDetailsModel.fromJson(Map<String, dynamic> json) =>
      GetBankDetailsModel(
        success: json["success"],
        totalBanks: json["totalBanks"],
        banksData: List<BanksDatum>.from(
            json["banksData"].map((x) => BanksDatum.fromJson(x))),
        mandatesData: List<dynamic>.from(json["mandatesData"].map((x) => x)),
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "totalBanks": totalBanks,
        "banksData": List<dynamic>.from(banksData!.map((x) => x.toJson())),
        "mandatesData": List<dynamic>.from(mandatesData!.map((x) => x)),
      };
}

class BanksDatum {
  BanksDatum({
    required this.accType,
    required this.accNumber,
    required this.bankName,
    required this.micrNo,
    required this.ifscCode,
    required this.defaultbank,
    required this.netBanking,
    required this.upi,
    required this.mandateData,
  });

  String accType;
  String accNumber;
  String bankName;
  String micrNo;
  String ifscCode;
  String defaultbank;
  bool netBanking;
  bool upi;
  List<dynamic> mandateData;

  factory BanksDatum.fromJson(Map<String, dynamic> json) => BanksDatum(
        accType: json["accType"],
        accNumber: json["accNumber"],
        bankName: json["bankName"],
        micrNo: json["micrNo"],
        ifscCode: json["ifscCode"],
        defaultbank: json["defaultbank"],
        netBanking: json["netBanking"],
        upi: json["upi"],
        mandateData: List<dynamic>.from(json["mandateData"].map((x) => x)),
      );

  Map<String, dynamic> toJson() => {
        "accType": accType,
        "accNumber": accNumber,
        "bankName": bankName,
        "micrNo": micrNo,
        "ifscCode": ifscCode,
        "defaultbank": defaultbank,
        "netBanking": netBanking,
        "upi": upi,
        "mandateData": List<dynamic>.from(mandateData.map((x) => x)),
      };
}
