class CountryDataModel {
  String? name;
}
