const HostingUrl = 'https://stag.app.moneyphi.com/api/ins/';

const OtpVerificationApi = 'authenticate/v1/validateMobileCode';
