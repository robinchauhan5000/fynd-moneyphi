import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

import '../Http/Interceptors.dart';
import '../Model/BankDetailsModel.dart';

class GetBankDetailsController extends ChangeNotifier {
  GetBankDetailsModel? getBankDetailsModel;
  bool isLoading = false;

  Future<GetBankDetailsModel> getBankDetails(context) async {
    isLoading = true;
    notifyListeners();
    Response response = await HttpService()
        .getRequest(endPoint: "/ins/sip/getallbank", context: context);
    isLoading = false;
    notifyListeners();
    getBankDetailsModel = GetBankDetailsModel.fromJson(response.data);
    print(response.data);

    return getBankDetailsModel!;
  }
}
