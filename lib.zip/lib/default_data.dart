class DefaultData {
  List<String> _languagesListDefault = [
    'English',
    'Gujarati',
    'Hindi',
  ];

  get languagesListDefault => _languagesListDefault;
}
