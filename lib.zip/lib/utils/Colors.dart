import 'package:flutter/material.dart';

const appColorPrimary = Color(0xff2AD95A);
const appsplashColor = Color(0xff1f9a3a);
const appColorPrimary2 = Color(0xff078CCA);
const appColorPrimaryDark = Color(0xff200e32);
const appButtonColor = Color(0xff848484);
const fontGrey = Color(0xffA4A3A8);
const fontWhite = Color(0xffffffff);
const textfieldColor = Color(0xffFDFDFD);

const String rupeeSymbol = '₹';
